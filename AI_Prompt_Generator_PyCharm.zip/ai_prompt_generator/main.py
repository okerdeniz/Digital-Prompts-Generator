"""
AI Prompt Generator for PyCharm
Generates Daily and Friday Prompts for AI Adoption / CoPilot exercises
"""
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
import os
import json
import zipfile
import shutil
import re
from pathlib import Path
from datetime import datetime

# Word document generation
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import copy

# ─── Constants ──────────────────────────────────────────────────────────────

INDUSTRIES = [
    "Healthcare",
    "Finance & Banking",
    "Legal",
    "Technology",
    "Manufacturing",
    "Retail & E-Commerce",
    "Education",
    "Government & Public Sector",
    "Real Estate",
    "Consulting & Professional Services",
    "Marketing & Advertising",
    "Logistics & Supply Chain",
    "Insurance",
    "Energy & Utilities",
    "Non-Profit",
]

AI_AGENTS = ["Claude AI", "GitHub Copilot", "ChatGPT", "Gemini"]

TOPIC_SUGGESTIONS = [
    "Email drafting and communication",
    "Data analysis and reporting",
    "Code review and debugging",
    "Document summarization",
    "Meeting notes and action items",
    "Customer support responses",
    "Research and synthesis",
    "Presentation creation",
    "Process documentation",
    "Creative brainstorming",
]

TEMPLATES_DIR = Path(__file__).parent / "templates"

# ─── Color Palette ──────────────────────────────────────────────────────────
BG_DARK = "#1e1f22"
BG_MED = "#2b2d31"
BG_LIGHT = "#313338"
ACCENT = "#5865f2"
ACCENT_HOVER = "#4752c4"
TEXT_PRIMARY = "#dbdee1"
TEXT_SECONDARY = "#949ba4"
SUCCESS = "#23a55a"
WARNING = "#f0b232"
BORDER = "#3f4147"


# ─── AI Client ──────────────────────────────────────────────────────────────

def call_ai(agent: str, api_key: str, prompt: str) -> str:
    """Call the selected AI agent and return the response text."""
    if not api_key or api_key.strip() == "":
        raise ValueError("API key is required. Please enter your API key in the left panel.")

    agent_lower = agent.lower()

    if "claude" in agent_lower:
        import anthropic
        client = anthropic.Anthropic(api_key=api_key.strip())
        message = client.messages.create(
            model="claude-opus-4-5",
            max_tokens=2048,
            messages=[{"role": "user", "content": prompt}]
        )
        return message.content[0].text

    elif "chatgpt" in agent_lower or "openai" in agent_lower:
        from openai import OpenAI
        client = OpenAI(api_key=api_key.strip())
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=2048,
        )
        return response.choices[0].message.content

    elif "gemini" in agent_lower:
        import google.generativeai as genai
        genai.configure(api_key=api_key.strip())
        model = genai.GenerativeModel("gemini-1.5-pro")
        response = model.generate_content(prompt)
        return response.text

    elif "copilot" in agent_lower:
        # GitHub Copilot uses OpenAI-compatible endpoint
        from openai import OpenAI
        client = OpenAI(
            api_key=api_key.strip(),
            base_url="https://api.githubcopilot.com",
        )
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=2048,
        )
        return response.choices[0].message.content

    else:
        raise ValueError(f"Unknown AI agent: {agent}")


# ─── Prompt Content Generator ────────────────────────────────────────────────

def build_generation_prompt(
    prompt_type: str,
    index: int,
    industry: str,
    agent: str,
    topics: str,
    total: int,
) -> str:
    """Build the meta-prompt that asks the AI to create a prompt exercise."""
    topic_hint = f"\nFocus areas / topics: {topics}" if topics.strip() else ""
    label = f"DP{index:02d}" if prompt_type == "daily" else f"FP{index:02d}"
    type_desc = "a concise daily" if prompt_type == "daily" else "a comprehensive Friday capstone"

    return f"""You are an AI adoption trainer creating {type_desc} CoPilot exercise prompt for practitioners in the {industry} industry.

Generate prompt #{index} of {total} total prompts.{topic_hint}
The AI tool being used is: {agent}

Return ONLY valid JSON with these exact keys (no markdown, no extra text):
{{
  "label": "{label}",
  "ai_prompt": "A clear, specific prompt for {agent} that a {industry} practitioner would use (2-4 sentences)",
  "email_message": "A realistic workplace email scenario that sets context for this exercise (3-5 sentences)",
  "learning_objective": "What skill or capability the practitioner will develop (1-2 sentences)",
  "demonstrated_capability": "The specific AI capability showcased in this exercise (1-2 sentences)",
  "test_response": "A sample/expected response that {agent} would provide to the ai_prompt (4-8 sentences)",
  "attachment_note": "Either 'None required' or describe what file attachment is needed"
}}

Requirements:
- Make it realistic for {industry} professionals
- Ensure progressive difficulty if this is not prompt #1
- Test response should demonstrate how {agent} specifically adds value
- Focus on practical, time-saving applications"""


# ─── Document Builder ─────────────────────────────────────────────────────────

def set_cell_background(cell, hex_color):
    """Set cell background color via XML."""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    tcPr.append(shd)


def set_cell_borders(cell, color="4472C4"):
    """Add borders to a table cell."""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = OxmlElement('w:tcBorders')
    for side in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{side}')
        border.set(qn('w:val'), 'single')
        border.set(qn('w:sz'), '6')
        border.set(qn('w:space'), '0')
        border.set(qn('w:color'), color)
        tcBorders.append(border)
    tcPr.append(tcBorders)


def add_bold_paragraph(cell, label, value, label_color="FFFFFF", value_color="000000"):
    """Add a labeled paragraph inside a cell."""
    cell.paragraphs[0].clear()
    p = cell.paragraphs[0]
    run_label = p.add_run(label)
    run_label.bold = True
    run_label.font.color.rgb = RGBColor.from_string(label_color)
    run_value = p.add_run(f"\n{value}")
    run_value.font.color.rgb = RGBColor.from_string(value_color)
    return p


def build_prompt_doc(data: dict, prompt_type: str, template_path: Path = None) -> Document:
    """
    Build a Word document for one prompt, using the template if available,
    otherwise creating from scratch.
    """
    # Try to load from template
    if template_path and template_path.exists():
        doc = Document(str(template_path))
        # Find and replace placeholders in template
        _fill_template(doc, data, prompt_type)
        return doc

    # Fallback: build from scratch
    return _build_doc_from_scratch(data, prompt_type)


def _fill_template(doc: Document, data: dict, prompt_type: str):
    """Fill placeholders in an existing Word template."""
    label = data.get("label", "")
    prefix = "DP" if prompt_type == "daily" else "FP"
    placeholder_prefix = f"{prefix}##"

    replacements = {
        placeholder_prefix: label,
        f"{prefix}##-__": label,
        "{{label}}": label,
        "{{ai_prompt}}": data.get("ai_prompt", ""),
        "{{email_message}}": data.get("email_message", ""),
        "{{learning_objective}}": data.get("learning_objective", ""),
        "{{demonstrated_capability}}": data.get("demonstrated_capability", ""),
        "{{test_response}}": data.get("test_response", ""),
        "{{attachment_note}}": data.get("attachment_note", "None required"),
    }

    field_map = {
        "AI Prompt": "ai_prompt",
        "E-Mail Message": "email_message",
        "Learning Objective": "learning_objective",
        "Demonstrated AI Capability": "demonstrated_capability",
        "Test Response": "test_response",
        "Attachment (if required)": "attachment_note",
    }

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    full_text = "".join(r.text for r in para.runs)

                    # Replace label placeholder
                    for old, new in replacements.items():
                        if old in full_text:
                            for run in para.runs:
                                run.text = run.text.replace(old, new)

                    # Check if next row should be filled with content
                    stripped = full_text.strip().strip("*").strip()
                    for field_label, data_key in field_map.items():
                        if field_label in stripped and not data.get(data_key, "") in full_text:
                            # The next empty cell in the table should get the data
                            pass

    # Also replace in blank cells adjacent to headers
    _fill_table_adjacent_cells(doc, data, field_map)


def _fill_table_adjacent_cells(doc: Document, data: dict, field_map: dict):
    """Fill cells that are adjacent to header cells in the template table."""
    for table in doc.tables:
        rows = list(table.rows)
        for i, row in enumerate(rows):
            for j, cell in enumerate(row.cells):
                cell_text = "".join(r.text for r in cell.paragraphs[0].runs).strip().strip("*").strip()
                for field_label, data_key in field_map.items():
                    if field_label in cell_text:
                        # Look for adjacent empty cells in same row or next row
                        content = data.get(data_key, "")
                        if content:
                            # Try cell to the right
                            if j + 1 < len(row.cells):
                                right_cell = row.cells[j + 1]
                                right_text = right_cell.text.strip()
                                if not right_text or right_text == cell_text:
                                    _set_cell_text(right_cell, content)
                                    break
                            # Try next row
                            if i + 1 < len(rows):
                                next_row = rows[i + 1]
                                if next_row.cells:
                                    next_cell = next_row.cells[0]
                                    if not next_cell.text.strip():
                                        _set_cell_text(next_cell, content)
                                        break


def _set_cell_text(cell, text: str):
    """Set text in a cell, preserving existing formatting where possible."""
    for para in cell.paragraphs:
        for run in para.runs:
            run.text = ""
    if cell.paragraphs:
        p = cell.paragraphs[0]
        if p.runs:
            p.runs[0].text = text
        else:
            p.add_run(text)
    else:
        cell.add_paragraph(text)


def _build_doc_from_scratch(data: dict, prompt_type: str) -> Document:
    """Build a clean Word document from scratch matching the template layout."""
    doc = Document()

    # Page margins
    section = doc.sections[0]
    section.top_margin = Inches(0.75)
    section.bottom_margin = Inches(0.75)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)

    label = data.get("label", "")
    header_color = "2E5FA3"  # Dark blue header

    # Title table (label + AI Prompt header)
    title_table = doc.add_table(rows=1, cols=2)
    title_table.style = "Table Grid"
    title_table.autofit = False

    from docx.shared import Cm
    title_table.columns[0].width = Inches(1.5)
    title_table.columns[1].width = Inches(5.5)

    lc = title_table.rows[0].cells[0]
    rc = title_table.rows[0].cells[1]

    set_cell_background(lc, header_color)
    set_cell_background(rc, header_color)

    lp = lc.paragraphs[0]
    lr = lp.add_run(label)
    lr.bold = True
    lr.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    lr.font.size = Pt(12)

    rp = rc.paragraphs[0]
    rr = rp.add_run("AI Prompt")
    rr.bold = True
    rr.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    rr.font.size = Pt(11)

    doc.add_paragraph("")

    # Content fields
    fields = [
        ("AI Prompt", "ai_prompt"),
        ("E-Mail Message", "email_message"),
        ("Learning Objective", "learning_objective"),
        ("Demonstrated AI Capability", "demonstrated_capability"),
        ("Test Response", "test_response"),
        ("Attachment (if required)", "attachment_note"),
    ]

    row_colors = ["EBF3FB", "FFFFFF"]

    for idx, (field_label, field_key) in enumerate(fields):
        tbl = doc.add_table(rows=2, cols=1)
        tbl.style = "Table Grid"
        tbl.autofit = False
        tbl.columns[0].width = Inches(7.0)

        # Header row
        hdr_cell = tbl.rows[0].cells[0]
        set_cell_background(hdr_cell, header_color)
        hp = hdr_cell.paragraphs[0]
        hr = hp.add_run(f"  {field_label}")
        hr.bold = True
        hr.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        hr.font.size = Pt(10)

        # Content row
        content_cell = tbl.rows[1].cells[0]
        set_cell_background(content_cell, row_colors[idx % 2])
        cp = content_cell.paragraphs[0]
        cr = cp.add_run(data.get(field_key, ""))
        cr.font.size = Pt(10)
        cr.font.color.rgb = RGBColor(0x20, 0x20, 0x20)

        # Cell padding
        for cell in [hdr_cell, content_cell]:
            tc = cell._tc
            tcPr = tc.get_or_add_tcPr()
            tcMar = OxmlElement('w:tcMar')
            for side in ['top', 'left', 'bottom', 'right']:
                m = OxmlElement(f'w:{side}')
                m.set(qn('w:w'), '100')
                m.set(qn('w:type'), 'dxa')
                tcMar.append(m)
            tcPr.append(tcMar)

        doc.add_paragraph("")

    return doc


# ─── Main App ─────────────────────────────────────────────────────────────────

class PromptGeneratorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AI Prompt Generator — PyCharm Plugin")
        self.geometry("1100x780")
        self.minsize(900, 650)
        self.configure(bg=BG_DARK)

        self._api_key = tk.StringVar()
        self._agent = tk.StringVar(value=AI_AGENTS[0])
        self._industry = tk.StringVar(value=INDUSTRIES[0])
        self._num_daily = tk.IntVar(value=5)
        self._topics = tk.StringVar()
        self._status = tk.StringVar(value="Ready")
        self._generated_files = []
        self._generating = False

        self._ensure_templates_dir()
        self._build_ui()

    def _ensure_templates_dir(self):
        TEMPLATES_DIR.mkdir(exist_ok=True)

    # ── UI Builder ─────────────────────────────────────────────────────────

    def _build_ui(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_sidebar()
        self._build_main_panel()
        self._build_status_bar()

    def _build_sidebar(self):
        sidebar = tk.Frame(self, bg=BG_MED, width=270)
        sidebar.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        sidebar.grid_propagate(False)
        sidebar.grid_rowconfigure(20, weight=1)

        # Logo / Title
        logo_frame = tk.Frame(sidebar, bg=ACCENT, height=60)
        logo_frame.pack(fill="x")
        logo_frame.pack_propagate(False)
        tk.Label(logo_frame, text="⚡ AI Prompt Generator",
                 bg=ACCENT, fg="white", font=("Segoe UI", 12, "bold"),
                 padx=12).pack(side="left", fill="y")

        self._section(sidebar, "API KEY")

        # API Key entry
        key_frame = tk.Frame(sidebar, bg=BG_MED)
        key_frame.pack(fill="x", padx=12, pady=(4, 8))
        self._api_entry = tk.Entry(
            key_frame, textvariable=self._api_key, show="•",
            bg=BG_LIGHT, fg=TEXT_PRIMARY, insertbackground=TEXT_PRIMARY,
            relief="flat", font=("Consolas", 10), bd=0
        )
        self._api_entry.pack(fill="x", ipady=6, padx=2)
        self._add_border(key_frame)

        toggle_btn = tk.Button(
            key_frame, text="👁", bg=BG_LIGHT, fg=TEXT_SECONDARY,
            relief="flat", cursor="hand2", bd=0,
            command=self._toggle_key_visibility
        )
        toggle_btn.pack(side="right", padx=4)

        self._section(sidebar, "AI AGENT")
        agent_frame = tk.Frame(sidebar, bg=BG_MED)
        agent_frame.pack(fill="x", padx=12, pady=(4, 8))
        agent_combo = ttk.Combobox(
            agent_frame, textvariable=self._agent,
            values=AI_AGENTS, state="readonly", font=("Segoe UI", 10)
        )
        agent_combo.pack(fill="x")
        self._style_combobox(agent_combo)

        self._section(sidebar, "INDUSTRY")
        industry_frame = tk.Frame(sidebar, bg=BG_MED)
        industry_frame.pack(fill="x", padx=12, pady=(4, 8))
        industry_combo = ttk.Combobox(
            industry_frame, textvariable=self._industry,
            values=INDUSTRIES, state="readonly", font=("Segoe UI", 10)
        )
        industry_combo.pack(fill="x")
        self._style_combobox(industry_combo)

        self._section(sidebar, "DAILY PROMPTS (1–26)")
        num_frame = tk.Frame(sidebar, bg=BG_MED)
        num_frame.pack(fill="x", padx=12, pady=(4, 8))

        self._num_spin = tk.Spinbox(
            num_frame, from_=1, to=26, increment=1,
            textvariable=self._num_daily,
            bg=BG_LIGHT, fg=TEXT_PRIMARY, insertbackground=TEXT_PRIMARY,
            buttonbackground=BG_LIGHT, relief="flat",
            font=("Segoe UI", 11, "bold"), width=5,
            justify="center"
        )
        self._num_spin.pack(side="left", ipady=4, padx=2)
        tk.Label(num_frame, text="prompts", bg=BG_MED,
                 fg=TEXT_SECONDARY, font=("Segoe UI", 9)).pack(side="left", padx=6)

        self._section(sidebar, "TEMPLATES FOLDER")
        tmpl_frame = tk.Frame(sidebar, bg=BG_MED)
        tmpl_frame.pack(fill="x", padx=12, pady=(4, 8))
        tk.Label(tmpl_frame, text=str(TEMPLATES_DIR),
                 bg=BG_MED, fg=TEXT_SECONDARY, font=("Consolas", 8),
                 wraplength=220, anchor="w").pack(fill="x")
        tk.Button(
            tmpl_frame, text="📂 Open Folder", bg=BG_LIGHT,
            fg=TEXT_PRIMARY, relief="flat", cursor="hand2",
            font=("Segoe UI", 9), padx=8, pady=4,
            command=lambda: os.startfile(str(TEMPLATES_DIR)) if os.name == "nt"
            else os.system(f"open {TEMPLATES_DIR}")
        ).pack(fill="x", pady=4)

        # Spacer
        tk.Frame(sidebar, bg=BG_MED).pack(fill="both", expand=True)

        # Version
        tk.Label(sidebar, text="v2.0.0  •  PyCharm Plugin",
                 bg=BG_MED, fg=TEXT_SECONDARY,
                 font=("Segoe UI", 8)).pack(pady=8)

    def _build_main_panel(self):
        main = tk.Frame(self, bg=BG_DARK)
        main.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(3, weight=1)

        # Header
        hdr = tk.Frame(main, bg=BG_MED, height=60)
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_propagate(False)
        tk.Label(hdr, text="Generate AI Adoption Prompts",
                 bg=BG_MED, fg=TEXT_PRIMARY,
                 font=("Segoe UI", 15, "bold"), padx=20).pack(side="left", fill="y")

        # Topics / Instructions
        topics_frame = tk.LabelFrame(
            main, text="  Topics / Instructions (optional)  ",
            bg=BG_DARK, fg=TEXT_SECONDARY, font=("Segoe UI", 9),
            bd=1, relief="groove"
        )
        topics_frame.grid(row=1, column=0, sticky="ew", padx=20, pady=(16, 8))
        topics_frame.grid_columnconfigure(0, weight=1)

        self._topics_text = tk.Text(
            topics_frame, height=4, bg=BG_LIGHT, fg=TEXT_PRIMARY,
            insertbackground=TEXT_PRIMARY, relief="flat",
            font=("Segoe UI", 10), padx=8, pady=6, wrap="word"
        )
        self._topics_text.grid(row=0, column=0, sticky="ew", padx=8, pady=8)

        hint = "e.g. Focus on email drafting, data analysis, and meeting summarization for senior managers."
        self._topics_text.insert("1.0", hint)
        self._topics_text.configure(fg=TEXT_SECONDARY)
        self._topics_text.bind("<FocusIn>", self._clear_hint)
        self._topics_text.bind("<FocusOut>", self._restore_hint)
        self._hint_text = hint

        # Buttons row
        btn_frame = tk.Frame(main, bg=BG_DARK)
        btn_frame.grid(row=2, column=0, sticky="ew", padx=20, pady=(4, 12))

        self._gen_btn = self._make_button(
            btn_frame, "🚀  Generate Prompts", ACCENT, "white",
            self._start_generation, padx=20
        )
        self._gen_btn.pack(side="left", padx=(0, 10))

        self._dl_btn = self._make_button(
            btn_frame, "⬇  Download ZIP", SUCCESS, "white",
            self._download_zip, padx=20
        )
        self._dl_btn.pack(side="left", padx=(0, 10))
        self._dl_btn.configure(state="disabled")

        self._clear_btn = self._make_button(
            btn_frame, "🗑  Clear", BG_LIGHT, TEXT_PRIMARY,
            self._clear_output, padx=12
        )
        self._clear_btn.pack(side="left")

        # Progress bar
        self._progress = ttk.Progressbar(main, mode="determinate", maximum=100)
        self._progress.grid(row=3, column=0, sticky="ew", padx=20, pady=(0, 4))

        # Log / Output
        log_frame = tk.LabelFrame(
            main, text="  Output Log  ",
            bg=BG_DARK, fg=TEXT_SECONDARY, font=("Segoe UI", 9),
            bd=1, relief="groove"
        )
        log_frame.grid(row=4, column=0, sticky="nsew", padx=20, pady=(4, 16))
        log_frame.grid_columnconfigure(0, weight=1)
        log_frame.grid_rowconfigure(0, weight=1)
        main.grid_rowconfigure(4, weight=1)

        self._log = scrolledtext.ScrolledText(
            log_frame, bg=BG_LIGHT, fg=TEXT_PRIMARY,
            font=("Consolas", 9), relief="flat",
            insertbackground=TEXT_PRIMARY, state="disabled",
            padx=10, pady=8
        )
        self._log.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
        self._log.tag_config("success", foreground=SUCCESS)
        self._log.tag_config("error", foreground="#ed4245")
        self._log.tag_config("info", foreground="#5865f2")
        self._log.tag_config("warning", foreground=WARNING)

    def _build_status_bar(self):
        status_bar = tk.Frame(self, bg=BG_MED, height=28)
        status_bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        status_bar.grid_propagate(False)
        tk.Label(status_bar, textvariable=self._status,
                 bg=BG_MED, fg=TEXT_SECONDARY,
                 font=("Segoe UI", 9), padx=12).pack(side="left", fill="y")

    # ── UI Helpers ──────────────────────────────────────────────────────────

    def _section(self, parent, text):
        f = tk.Frame(parent, bg=BG_MED)
        f.pack(fill="x", padx=12, pady=(12, 2))
        tk.Label(f, text=text, bg=BG_MED, fg=TEXT_SECONDARY,
                 font=("Segoe UI", 8, "bold")).pack(side="left")

    def _add_border(self, frame):
        frame.configure(highlightbackground=BORDER,
                        highlightthickness=1, bd=0)

    def _style_combobox(self, combo):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TCombobox",
                        fieldbackground=BG_LIGHT,
                        background=BG_LIGHT,
                        foreground=TEXT_PRIMARY,
                        arrowcolor=TEXT_PRIMARY,
                        bordercolor=BORDER,
                        selectbackground=ACCENT,
                        selectforeground="white")

    def _make_button(self, parent, text, bg, fg, command, padx=10):
        btn = tk.Button(
            parent, text=text, bg=bg, fg=fg,
            relief="flat", cursor="hand2",
            font=("Segoe UI", 10, "bold"),
            padx=padx, pady=8, bd=0,
            activebackground=ACCENT_HOVER,
            activeforeground="white",
            command=command
        )
        btn.bind("<Enter>", lambda e: btn.configure(bg=ACCENT_HOVER if bg == ACCENT else bg))
        btn.bind("<Leave>", lambda e: btn.configure(bg=bg))
        return btn

    def _toggle_key_visibility(self):
        current = self._api_entry.cget("show")
        self._api_entry.configure(show="" if current == "•" else "•")

    def _clear_hint(self, event):
        if self._topics_text.get("1.0", "end-1c") == self._hint_text:
            self._topics_text.delete("1.0", "end")
            self._topics_text.configure(fg=TEXT_PRIMARY)

    def _restore_hint(self, event):
        if not self._topics_text.get("1.0", "end-1c").strip():
            self._topics_text.insert("1.0", self._hint_text)
            self._topics_text.configure(fg=TEXT_SECONDARY)

    def _log_msg(self, msg, tag=""):
        self._log.configure(state="normal")
        ts = datetime.now().strftime("%H:%M:%S")
        self._log.insert("end", f"[{ts}] {msg}\n", tag)
        self._log.see("end")
        self._log.configure(state="disabled")

    def _set_status(self, msg):
        self._status.set(msg)
        self.update_idletasks()

    # ── Generation Logic ────────────────────────────────────────────────────

    def _start_generation(self):
        if self._generating:
            return

        api_key = self._api_key.get().strip()
        if not api_key:
            messagebox.showerror("API Key Required",
                                 "Please enter your API key in the left panel before generating.")
            return

        num = self._num_daily.get()
        if not (1 <= num <= 26):
            messagebox.showerror("Invalid Count",
                                 "Number of daily prompts must be between 1 and 26.")
            return

        topics = self._topics_text.get("1.0", "end-1c").strip()
        if topics == self._hint_text:
            topics = ""

        self._generated_files = []
        self._progress["value"] = 0
        self._dl_btn.configure(state="disabled")
        self._gen_btn.configure(state="disabled")
        self._generating = True

        thread = threading.Thread(
            target=self._run_generation,
            args=(api_key, self._agent.get(), self._industry.get(), num, topics),
            daemon=True
        )
        thread.start()

    def _run_generation(self, api_key, agent, industry, num_daily, topics):
        try:
            out_dir = Path.home() / "AI_Prompts_Output" / datetime.now().strftime("%Y%m%d_%H%M%S")
            out_dir.mkdir(parents=True, exist_ok=True)
            self._log_msg(f"Output folder: {out_dir}", "info")

            total_tasks = num_daily + 1  # daily + 1 friday
            completed = 0

            # Get template paths
            daily_template = TEMPLATES_DIR / "Daily_Prompt_Template.docx"
            friday_template = TEMPLATES_DIR / "Friday_Prompt_Template.docx"

            # ── Daily Prompts ──
            self._log_msg(f"Generating {num_daily} Daily Prompts...", "info")
            for i in range(1, num_daily + 1):
                self._set_status(f"Generating Daily Prompt {i}/{num_daily}...")
                try:
                    meta_prompt = build_generation_prompt(
                        "daily", i, industry, agent, topics, num_daily
                    )
                    raw = call_ai(agent, api_key, meta_prompt)
                    data = self._parse_json(raw)
                    data["label"] = f"DP{i:02d}"

                    doc = build_prompt_doc(data, "daily", daily_template)
                    fname = out_dir / f"DP{i:02d}_{industry.replace(' ', '_')}.docx"
                    doc.save(str(fname))
                    self._generated_files.append(str(fname))
                    self._log_msg(f"  ✓ {fname.name} — {data.get('ai_prompt', '')[:80]}...", "success")

                except Exception as e:
                    self._log_msg(f"  ✗ DP{i:02d} failed: {e}", "error")

                completed += 1
                self._progress["value"] = int(completed / total_tasks * 100)
                self.update_idletasks()

            # ── Friday Prompt ──
            self._log_msg("Generating Friday Capstone Prompt...", "info")
            self._set_status("Generating Friday Prompt...")
            try:
                meta_prompt = build_generation_prompt(
                    "friday", 1, industry, agent, topics, num_daily
                )
                raw = call_ai(agent, api_key, meta_prompt)
                data = self._parse_json(raw)
                data["label"] = "FP01"

                doc = build_prompt_doc(data, "friday", friday_template)
                fname = out_dir / f"FP01_{industry.replace(' ', '_')}_Capstone.docx"
                doc.save(str(fname))
                self._generated_files.append(str(fname))
                self._log_msg(f"  ✓ {fname.name}", "success")

            except Exception as e:
                self._log_msg(f"  ✗ FP01 failed: {e}", "error")

            completed += 1
            self._progress["value"] = 100
            self.update_idletasks()

            self._log_msg(
                f"\n✅ Done! {len(self._generated_files)} files in: {out_dir}", "success"
            )
            self._set_status(f"✅ Generated {len(self._generated_files)} prompts in {out_dir}")
            self.after(0, lambda: self._dl_btn.configure(state="normal"))

        except Exception as e:
            self._log_msg(f"Fatal error: {e}", "error")
            self._set_status(f"Error: {e}")

        finally:
            self._generating = False
            self.after(0, lambda: self._gen_btn.configure(state="normal"))

    def _parse_json(self, raw: str) -> dict:
        """Extract JSON from AI response (handles markdown fences)."""
        # Strip markdown fences
        cleaned = re.sub(r"```(?:json)?", "", raw).strip().strip("`").strip()
        # Find JSON object
        start = cleaned.find("{")
        end = cleaned.rfind("}") + 1
        if start >= 0 and end > start:
            return json.loads(cleaned[start:end])
        raise ValueError(f"No valid JSON found in response: {raw[:200]}")

    def _download_zip(self):
        if not self._generated_files:
            messagebox.showwarning("No Files", "No generated files to download.")
            return

        save_path = filedialog.asksaveasfilename(
            defaultextension=".zip",
            filetypes=[("ZIP files", "*.zip")],
            initialfile=f"AI_Prompts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip",
            title="Save Prompts ZIP"
        )
        if not save_path:
            return

        try:
            with zipfile.ZipFile(save_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for fpath in self._generated_files:
                    if os.path.exists(fpath):
                        zf.write(fpath, os.path.basename(fpath))
            self._log_msg(f"📦 ZIP saved: {save_path}", "success")
            self._set_status(f"ZIP saved: {save_path}")
            messagebox.showinfo("Download Complete",
                                f"ZIP file saved:\n{save_path}")
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def _clear_output(self):
        self._log.configure(state="normal")
        self._log.delete("1.0", "end")
        self._log.configure(state="disabled")
        self._progress["value"] = 0
        self._generated_files = []
        self._dl_btn.configure(state="disabled")
        self._set_status("Ready")


if __name__ == "__main__":
    app = PromptGeneratorApp()
    app.mainloop()
