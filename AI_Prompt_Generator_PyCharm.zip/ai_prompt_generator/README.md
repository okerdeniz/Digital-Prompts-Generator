# AI Prompt Generator — PyCharm Plugin

A GUI tool for generating Daily and Friday AI Adoption Prompts for CoPilot exercises.
Built with Python/Tkinter and designed to run as an External Tool inside PyCharm.

---

## Features

- 🤖 **Multi-Agent Support** — Claude AI, GitHub Copilot, ChatGPT, Gemini
- 🏭 **Industry Selection** — 15 industry verticals
- 📅 **Daily Prompts** — 1 to 26 prompts (configurable, increments of 1)
- 📆 **Friday Capstone Prompt** — Auto-generated alongside daily prompts
- 📝 **Template-Based** — Uses Word templates from the `templates/` folder
- 📦 **Download ZIP** — Download all generated `.docx` files in one click
- 🔑 **API Key Management** — Secure masked key entry in the sidebar
- ✍️ **Custom Topics** — Optional instructions/topic focus box

---

## Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Add Word Templates (Optional but Recommended)

Place your Word template files in the `templates/` folder:

```
ai_prompt_generator/
  templates/
    Daily_Prompt_Template.docx
    Friday_Prompt_Template.docx
```

If templates are not found, documents are generated from scratch with matching layout.

### 3. Configure PyCharm as External Tool

Go to **File → Settings → Tools → External Tools** → click **+**

| Field       | Value                              |
|-------------|------------------------------------|
| Name        | AI Prompt Generator                |
| Program     | `python`                           |
| Arguments   | `$ProjectFileDir$/main.py`         |
| Working Dir | `$ProjectFileDir$`                 |

Then access it from **Tools → External Tools → AI Prompt Generator**

---

## Usage

1. **Enter API Key** — Paste your API key in the top-left field (masked by default)
2. **Select AI Agent** — Choose from Claude AI, GitHub Copilot, ChatGPT, or Gemini
3. **Select Industry** — Pick the industry for contextual prompt generation
4. **Set Count** — Choose 1–26 daily prompts using the spinner
5. **Add Topics** *(optional)* — Describe focus areas or special instructions
6. **Click Generate** — Prompts are generated and saved locally
7. **Download ZIP** — Package all `.docx` files into a ZIP for distribution

---

## API Keys

| Agent         | Where to Get Key                              |
|---------------|-----------------------------------------------|
| Claude AI     | https://console.anthropic.com                 |
| ChatGPT       | https://platform.openai.com/api-keys          |
| Gemini        | https://aistudio.google.com/app/apikey        |
| GitHub Copilot| GitHub Settings → Developer Settings → PATs   |

---

## Template Fields

Each generated `.docx` file contains:

| Field                    | Description                                  |
|--------------------------|----------------------------------------------|
| Label (DP##/FP##)        | Prompt identifier                            |
| AI Prompt                | The actual prompt text for the AI agent      |
| E-Mail Message           | Workplace email scenario for context         |
| Learning Objective       | Skill the practitioner develops              |
| Demonstrated AI Capability | Specific AI capability showcased           |
| Test Response            | Sample response from the AI                  |
| Attachment (if required) | Any file attachments needed                  |

---

## Output

Generated files are saved to:
```
~/AI_Prompts_Output/<timestamp>/
  DP01_Healthcare.docx
  DP02_Healthcare.docx
  ...
  FP01_Healthcare_Capstone.docx
```
